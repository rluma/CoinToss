﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Coin_Toss
{
    internal class Coin
    {
           // Field to represent the side facing up;
           private string sideUp;
        
         // Random number generator
            Random rand = new Random();

          public Coin()
        {
            sideUp = "Heads";
        }
 
           public void Toss()
        {
            if (rand.Next(2) == 0)
            {
                sideUp = "Heads";
            }
            else
            {
                sideUp = "Tails";
            }
        }
        public string GetSideUp()
        {
            return sideUp;
        }
    }
}
